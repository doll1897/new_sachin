package com.cts.service;

import com.cts.bean.RegisterBean;

public interface RegisterService {
    public boolean registerUser(RegisterBean bean);
    
}
