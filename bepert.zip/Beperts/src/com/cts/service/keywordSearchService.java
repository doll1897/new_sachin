package com.cts.service;

public interface keywordSearchService {
	public String keywordSearch(String keyword);
}
