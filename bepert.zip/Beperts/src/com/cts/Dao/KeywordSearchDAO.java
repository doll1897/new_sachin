package com.cts.Dao;

public interface KeywordSearchDAO {
	public String keywordSearch(String keyword);


}
